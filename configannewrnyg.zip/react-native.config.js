module.exports = {
  assets: [
    './assets/fonts',
    './node_modules/react-native-vector-icons/Fonts'
  ],
};
